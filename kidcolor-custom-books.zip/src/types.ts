export interface PageOutline {
  pageNumber: number;
  title: string;
  prompt: string;
  caption: string;
}

export interface BookOutline {
  coverTitle: string;
  pages: PageOutline[];
}

export interface GeneratedPage {
  pageNumber: number;
  title: string;
  caption: string;
  type: "svg" | "raster";
  content: string; // Base64 data URI for raster, or raw XML string for SVG
  isFallback?: boolean;
  status: "pending" | "generating" | "success" | "error";
  error?: string;
}

export interface AppState {
  theme: string;
  childName: string;
  generationMode: "imagen" | "svg";
  bookOutline: BookOutline | null;
  generatedPages: GeneratedPage[];
  isGeneratingOutline: boolean;
  isGeneratingPages: boolean;
  currentStep: "setup" | "outline" | "creating" | "finished";
  error: string | null;
}
