import { jsPDF } from "jspdf";
import { GeneratedPage } from "../types";

// Helper: Converts an inline SVG XML string to a Base64 PNG URL using HTML5 Canvas
export async function svgToPngDataUri(svgString: string, width = 1600, height = 2000): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      const img = new Image();
      // Use Blob to load SVG data directly (handles special chars seamlessly)
      const svgBlob = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(svgBlob);

      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        
        if (ctx) {
          // Fill pure white background
          ctx.fillStyle = "#FFFFFF";
          ctx.fillRect(0, 0, width, height);
          
          // Draw the SVG image
          ctx.drawImage(img, 0, 0, width, height);
          
          // Export high quality PNG
          const pngUrl = canvas.toDataURL("image/png", 1.0);
          URL.revokeObjectURL(url);
          resolve(pngUrl);
        } else {
          URL.revokeObjectURL(url);
          reject(new Error("Unable to get 2D Canvas context."));
        }
      };

      img.onerror = (err) => {
        URL.revokeObjectURL(url);
        console.error("SVG Image extraction error:", err);
        reject(new Error("Failed to render SVG vector path."));
      };

      img.src = url;
    } catch (e) {
      reject(e);
    }
  });
}

// Main PDF Generator function
export async function generateColoringBookPdf(
  coverTitle: string,
  childName: string,
  theme: string,
  pages: GeneratedPage[],
  onProgress?: (msg: string) => void
): Promise<Blob> {
  // Letter size is standard: 215.9mm x 279.4mm (8.5" x 11")
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "letter",
  });

  const pageW = 215.9;
  const pageH = 279.4;

  // ==========================================
  // PAGE 1: COVER PAGE
  // ==========================================
  onProgress?.("Designing custom cover page...");

  // Double-line Border
  doc.setLineWidth(1.5);
  doc.setDrawColor(30, 41, 59); // Deep dark slate
  doc.rect(10, 10, pageW - 20, pageH - 20); // Outer frame
  
  doc.setLineWidth(0.5);
  doc.rect(12, 12, pageW - 24, pageH - 24); // Inner frame

  // Add decorative background circles/dots (coloring book style)
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.3);
  
  // Draw some simple vector decorations (stars/bubbles to color in)
  const drawStar = (cx: number, cy: number, r: number) => {
    const pts = [];
    for (let i = 0; i < 10; i++) {
      const angle = (Math.PI / 5) * i - Math.PI / 2;
      const currR = i % 2 === 0 ? r : r * 0.4;
      pts.push([cx + Math.cos(angle) * currR, cy + Math.sin(angle) * currR]);
    }
    // Draw polygon lines
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.6);
    for (let i = 0; i < pts.length; i++) {
      const nextPt = pts[(i + 1) % pts.length];
      doc.line(pts[i][0], pts[i][1], nextPt[0], nextPt[1]);
    }
  };

  // Decorative vector stars on the cover
  drawStar(35, 45, 10);
  drawStar(pageW - 35, 45, 10);
  drawStar(45, pageH - 50, 12);
  drawStar(pageW - 45, pageH - 50, 12);

  // Big friendly title
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30, 41, 59);
  
  // Title text layout
  doc.setFontSize(28);
  const splitTitle = doc.splitTextToSize(coverTitle.toUpperCase(), pageW - 40);
  let currentY = 70;
  splitTitle.forEach((line: string) => {
    doc.text(line, pageW / 2, currentY, { align: "center" });
    currentY += 12;
  });

  // Sub-header
  currentY += 15;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(14);
  doc.setTextColor(100, 116, 139);
  doc.text("A COLORING BOOK CREATED ESPECIALLY FOR", pageW / 2, currentY, { align: "center" });

  // Child's Name in massive outlined text
  currentY += 25;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(36);
  doc.setTextColor(30, 41, 59);
  
  // Custom Banner behind name
  const nameWidth = doc.getTextWidth(childName.toUpperCase()) + 20;
  doc.setLineWidth(1.2);
  doc.setDrawColor(0, 0, 0);
  doc.setFillColor(255, 255, 255);
  doc.rect(pageW / 2 - nameWidth / 2, currentY - 14, nameWidth, 20, "FD");
  doc.text(childName.toUpperCase(), pageW / 2, currentY, { align: "center" });

  // Fun helper caption
  currentY += 25;
  doc.setFont("helvetica", "italic");
  doc.setFontSize(12);
  doc.setTextColor(100, 116, 139);
  doc.text("Grab your crayons, colored pencils, or markers!", pageW / 2, currentY, { align: "center" });

  // Bottom watermark / credit
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(148, 163, 184);
  doc.text("PERSISTENT MEMORIES • COLORING APP GENERATOR", pageW / 2, pageH - 22, { align: "center" });

  // ==========================================
  // PAGES 2 - 6: COLORING PAGES
  // ==========================================
  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];
    onProgress?.(`Composing page ${i + 1} of 5: ${page.title}...`);

    doc.addPage();

    // Standard Single Page Frame
    doc.setLineWidth(0.8);
    doc.setDrawColor(50, 50, 50);
    doc.rect(10, 10, pageW - 20, pageH - 20);

    // Page Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(30, 41, 59);
    doc.text(`${i + 1}. ${page.title.toUpperCase()}`, pageW / 2, 22, { align: "center" });

    // Render coloring art
    let cleanImageUri = "";
    if (page.type === "svg") {
      // Need to rasterize SVG inline vector text/geometries so jsPDF supports it
      cleanImageUri = await svgToPngDataUri(page.content);
    } else {
      cleanImageUri = page.content;
    }

    // Embed the image in 4:5 portrait ratio inside the Letter portrait page
    // Placing image horizontally centered
    const imgMarginX = 18; 
    const imgW = pageW - (imgMarginX * 2); // 179.9mm
    const imgH = imgW * (5 / 4); // 224.8mm
    const imgY = 28; // Keep ample spacing at bottom for text
    
    doc.addImage(cleanImageUri, "PNG", imgMarginX, imgY, imgW, imgH);

    // Beautiful rounded card caption frame at bottom
    doc.setLineWidth(0.4);
    doc.setDrawColor(200, 200, 200);
    doc.setFillColor(250, 250, 250);
    
    const captionBoxY = imgY + imgH + 5;
    const captionBoxH = 12;
    doc.rect(imgMarginX, captionBoxY, imgW, captionBoxH, "FD");

    // Print text inside the caption frame
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(51, 65, 85);
    
    const wrappedCaption = doc.splitTextToSize(page.caption, imgW - 6);
    doc.text(wrappedCaption, pageW / 2, captionBoxY + 7, { align: "center" });

    // Page number tracker at absolute bottom
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(148, 163, 184);
    doc.text(`Page ${i + 1} of 5`, pageW - 15, pageH - 14, { align: "right" });
  }

  onProgress?.("Wrapping up coloring book...");
  return doc.output("blob");
}
