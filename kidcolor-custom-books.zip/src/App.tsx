import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  BookOpen, 
  Download, 
  Printer, 
  RefreshCw, 
  User, 
  Paintbrush, 
  Check, 
  AlertCircle, 
  FileText, 
  ArrowRight,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Trash2,
  HelpCircle,
  Scissors
} from "lucide-react";
import { AppState, PageOutline, GeneratedPage } from "./types";
import { generateColoringBookPdf } from "./utils/pdfGenerator";

const SUGGESTIONS = [
  { name: "Oliver", theme: "Space Dinosaurs", icon: "🦖🚀", color: "from-amber-400 to-orange-500" },
  { name: "Mia", theme: "Deep Sea Mermaid Castles", icon: "🧜‍♀️🏰", color: "from-teal-400 to-emerald-500" },
  { name: "Leo", theme: "Safari Animals in Go-Karts", icon: "🦁🏎️", color: "from-sky-400 to-blue-500" },
  { name: "Sienna", theme: "Magical Forest Tea Party", icon: "🧚‍♀️🍰", color: "from-pink-400 to-rose-500" },
  { name: "Noah", theme: "Friendly Robots in Space Candy Land", icon: "🤖🍭", color: "from-purple-400 to-indigo-500" }
];

const PASTEL_PALETTE = [
  { name: "Fresh White", value: "#FFFFFF" },
  { name: "Strawberry Pastel", value: "#FFADAD" },
  { name: "Peach Pastel", value: "#FFD6A5" },
  { name: "Lemon Pastel", value: "#FDFFB6" },
  { name: "Mint Pastel", value: "#CAFFBF" },
  { name: "Ocean Pastel", value: "#9BF6FF" },
  { name: "Sky Pastel", value: "#A0C4FF" },
  { name: "Lavender Pastel", value: "#BDB2FF" },
  { name: "Rose Pastel", value: "#FFC6FF" },
  { name: "Crayon Gray", value: "#D1D5DB" }
];

export default function App() {
  const [state, setState] = useState<AppState>({
    theme: "",
    childName: "",
    generationMode: "svg", // default is SVG is fast and gorgeous
    bookOutline: null,
    generatedPages: [],
    isGeneratingOutline: false,
    isGeneratingPages: false,
    currentStep: "setup",
    error: null
  });

  const [activePageIndex, setActivePageIndex] = useState<number>(0);
  const [pdfGenerationMsg, setPdfGenerationMsg] = useState<string | null>(null);
  const [isPdfDownloading, setIsPdfDownloading] = useState(false);
  const [selectedPaintColor, setSelectedPaintColor] = useState<string>("#FFADAD");

  // Local coloring override state (pageNumber -> elementId -> color) for interactive canvas coloring
  const [interactiveColors, setInteractiveColors] = useState<Record<number, Record<string, string>>>({});
  
  // Custom print ref
  const pagePrintRef = useRef<HTMLDivElement>(null);

  const resetApp = () => {
    setState({
      theme: "",
      childName: "",
      generationMode: "svg",
      bookOutline: null,
      generatedPages: [],
      isGeneratingOutline: false,
      isGeneratingPages: false,
      currentStep: "setup",
      error: null
    });
    setInteractiveColors({});
    setActivePageIndex(0);
  };

  const handleApplySuggestion = (sug: typeof SUGGESTIONS[0]) => {
    setState(prev => ({
      ...prev,
      childName: sug.name,
      theme: sug.theme,
      error: null
    }));
  };

  const generateBookOutline = async () => {
    if (!state.childName.trim()) {
      setState(prev => ({ ...prev, error: "Please enter a child's name!" }));
      return;
    }
    if (!state.theme.trim()) {
      setState(prev => ({ ...prev, error: "Please write a cool theme!" }));
      return;
    }

    setState(prev => ({ ...prev, isGeneratingOutline: true, error: null }));

    try {
      const response = await fetch("/api/generate-outlines", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          theme: state.theme,
          childName: state.childName
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to generate coloring outlines.");
      }

      const outline = await response.json();
      setState(prev => ({
        ...prev,
        bookOutline: outline,
        isGeneratingOutline: false,
        currentStep: "outline"
      }));
    } catch (err: any) {
      console.error(err);
      setState(prev => ({
        ...prev,
        isGeneratingOutline: false,
        error: err.message || "Something went wrong. Let's try again!"
      }));
    }
  };

  // Modify manual outline entries before launching active creation
  const handleUpdateOutlinePage = (index: number, field: 'title' | 'prompt' | 'caption', value: string) => {
    if (!state.bookOutline) return;
    const updatedPages = [...state.bookOutline.pages];
    updatedPages[index] = {
      ...updatedPages[index],
      [field]: value
    };
    setState(prev => ({
      ...prev,
      bookOutline: {
        ...prev.bookOutline!,
        pages: updatedPages
      }
    }));
  };

  const triggerGenerateAllPages = async () => {
    if (!state.bookOutline) return;

    setState(prev => ({
      ...prev,
      isGeneratingPages: true,
      currentStep: "creating",
      generatedPages: state.bookOutline!.pages.map(p => ({
        pageNumber: p.pageNumber,
        title: p.title,
        caption: p.caption,
        type: "svg", // initial placeholder type
        content: "",
        status: "pending"
      }))
    }));

    const activeOutline = state.bookOutline;
    
    // Generate pages sequentially to avoid hitting model demand limits and timeouts
    for (let index = 0; index < activeOutline.pages.length; index++) {
      const page = activeOutline.pages[index];

      // Update state to "generating"
      setState(prev => {
        const pages = [...prev.generatedPages];
        if (pages[index]) {
          pages[index].status = "generating";
        }
        return { ...prev, generatedPages: pages };
      });

      try {
        const response = await fetch("/api/generate-page-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            theme: state.theme,
            childName: state.childName,
            pageNumber: page.pageNumber,
            title: page.title,
            prompt: page.prompt,
            caption: page.caption,
            mode: state.generationMode
          })
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || "Failed to generate coloring page.");
        }

        const data = await response.json();
        
        setState(prev => {
          const pages = [...prev.generatedPages];
          if (pages[index]) {
            pages[index] = {
              ...pages[index],
              status: "success",
              type: data.type === "raster" ? "raster" : "svg",
              content: data.content,
              isFallback: data.isFallback || false
            };
          }
          return { ...prev, generatedPages: pages };
        });
      } catch (err: any) {
        console.error(`Page ${index + 1} generation failed:`, err);
        setState(prev => {
          const pages = [...prev.generatedPages];
          if (pages[index]) {
            pages[index] = {
              ...pages[index],
              status: "error",
              error: err.message || "Failed to generate."
            };
          }
          return { ...prev, generatedPages: pages };
        });
      }

      // Add a tiny 600ms breathing window between page requests to allow rate limit relaxation
      if (index < activeOutline.pages.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 600));
      }
    }

    setState(prev => ({
      ...prev,
      isGeneratingPages: false,
      currentStep: "finished"
    }));
  };

  const handleDownloadPdf = async () => {
    if (!state.bookOutline || state.generatedPages.length === 0) return;
    setIsPdfDownloading(true);
    setPdfGenerationMsg("Gathering pages...");

    try {
      // Check that all pages generated successfully
      const successfulPages = state.generatedPages.filter(p => p.status === "success");
      if (successfulPages.length === 0) {
        throw new Error("No pages have been successfully drawn yet.");
      }

      // If interactive colors are applied to elements in SVGs, let's inject those colored styles into the SVG XML strings before saving to the PDF!
      // This is an absolute masterstroke of polish!
      const coloredPagesWithOverrides = successfulPages.map(page => {
        if (page.type === "svg" && interactiveColors[page.pageNumber]) {
          let updatedContent = page.content;
          const styleOverrides = interactiveColors[page.pageNumber];
          
          // Basic injection: parse SVG string, change styles/fills, and serialized back or string replace
          // Since our kids coloring SVG paths commonly have distinct IDs or we can find elements, we can parse them.
          // Alternatively, we can inject a style block inside the SVG that overrides fills!
          // E.g. <style>#path_id { fill: #color !important; }</style>
          let styleBlock = "<style>";
          Object.entries(styleOverrides).forEach(([id, color]) => {
            if (id) {
              styleBlock += `[id="${id}"], #${id} { fill: ${color} !important; }\n`;
            }
          });
          styleBlock += "</style>";
          
          // Insert after the first <svg ...> tag
          const svgTagEnd = updatedContent.indexOf(">");
          if (svgTagEnd >= 0) {
            updatedContent = updatedContent.substring(0, svgTagEnd + 1) + styleBlock + updatedContent.substring(svgTagEnd + 1);
          }
          
          return {
            ...page,
            content: updatedContent
          };
        }
        return page;
      });

      const pdfBlob = await generateColoringBookPdf(
        state.bookOutline.coverTitle,
        state.childName,
        state.theme,
        coloredPagesWithOverrides,
        (msg) => setPdfGenerationMsg(msg)
      );

      // Trigger download
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${state.childName.trim().replace(/\s+/g, "_")}_Coloring_Book.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e: any) {
      console.error(e);
      alert(e.message || "Failed to build PDF. Please try again.");
    } finally {
      setIsPdfDownloading(false);
      setPdfGenerationMsg(null);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Click handler inside the SVG container to support direct digital coloring!
  // It intercepts clicks on paths/rects/circles inside the raw inline rendering
  const handleSvgClick = (e: React.MouseEvent<HTMLDivElement>, pageNum: number) => {
    const target = e.target as SVGElement;
    if (!target) return;

    // Reject coloring the background rect or the container div
    if (target.tagName.toLowerCase() === "svg" || target.id === "svg-background") {
      return;
    }

    // Give the element an ID if it doesn't already have one, or use a custom selector
    let elementId = target.getAttribute("id");
    if (!elementId) {
      // Create a unique deterministic ID based on tag, attributes, or random string
      elementId = `coloring-el-${Math.random().toString(36).substring(2, 9)}`;
      target.setAttribute("id", elementId);
    }

    // Update state
    setInteractiveColors(prev => ({
      ...prev,
      [pageNum]: {
        ...(prev[pageNum] || {}),
        [elementId!]: selectedPaintColor
      }
    }));
  };

  const clearDigitalColors = (pageNum: number) => {
    setInteractiveColors(prev => {
      const copy = { ...prev };
      delete copy[pageNum];
      return copy;
    });
  };

  const activePage = state.generatedPages[activePageIndex];

  return (
    <div className="min-h-screen bg-[#FFFDF9] text-slate-800 font-sans selection:bg-amber-200">
      
      {/* Decorative top rainbow bar */}
      <div className="h-2 w-full bg-gradient-to-r from-red-400 via-orange-400 via-amber-400 via-emerald-400 via-cyan-400 via-purple-400 via-pink-400" />
      
      {/* Header element */}
      <header className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between border-b border-orange-100/50">
        <div className="flex items-center gap-3 cursor-pointer" onClick={resetApp}>
          <div className="relative">
            <span className="text-4xl">🎨</span>
            <motion.span 
              className="absolute -top-1 -right-1 text-xl"
              animate={{ rotate: [0, 15, -15, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              ✨
            </motion.span>
          </div>
          <div>
            <h1 className="text-2xl font-bold font-display tracking-tight text-slate-900 flex items-center gap-2">
              Coloring Book <span className="text-orange-500">Generator</span>
            </h1>
            <p className="text-xs text-slate-500 font-mono tracking-wider">CREATIVE CRAYON MACHINE</p>
          </div>
        </div>

        {state.currentStep !== "setup" && (
          <button 
            onClick={resetApp}
            className="flex items-center gap-2 text-sm text-slate-600 hover:text-orange-500 bg-slate-100/80 hover:bg-orange-50 px-3 py-1.5 rounded-full transition-colors border border-slate-200/50"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Create New Book</span>
          </button>
        )}
      </header>

      <main className="max-w-5xl mx-auto px-6 py-10">
        
        {/* State Error Banner */}
        {state.error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-red-700 text-sm shadow-sm">
            <AlertCircle className="h-5 w-5 shrink-0 text-red-500 mt-0.5" />
            <div>
              <p className="font-semibold">Oops! Something went wrong</p>
              <p className="text-red-600/90">{state.error}</p>
            </div>
          </div>
        )}

        {/* STEP 1: INITIAL SETUP DIALOGS */}
        <AnimatePresence mode="wait">
          {state.currentStep === "setup" && (
            <motion.div
              key="setup-screen"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              {/* Form Controls Card */}
              <div className="lg:col-span-7 bg-white p-8 rounded-3xl border border-orange-100 shadow-xl shadow-orange-500/5 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-100/40 rounded-full blur-2xl -z-10" />
                
                <h2 className="text-xl font-bold font-display text-slate-800 mb-6 flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-amber-500" />
                  Whose coloring book are we drawing?
                </h2>

                <div className="space-y-6">
                  {/* Child's Name Input */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                      <User className="h-4 w-4 text-slate-400" />
                      Child's Name
                    </label>
                    <input 
                      type="text"
                      className="w-full px-4 py-3 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-orange-100 focus:border-orange-400 transition-all font-semibold placeholder:text-slate-400"
                      placeholder="e.g. Oliver, Mia, Leo"
                      value={state.childName}
                      onChange={(e) => setState(prev => ({ ...prev, childName: e.target.value, error: null }))}
                    />
                  </div>

                  {/* Theme Input */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                      <Paintbrush className="h-4 w-4 text-slate-400" />
                      Book Theme Adventure
                    </label>
                    <input 
                      type="text"
                      className="w-full px-4 py-3 border border-slate-200 rounded-2xl focus:outline-none focus:ring-4 focus:ring-orange-100 focus:border-orange-400 transition-all font-semibold placeholder:text-slate-400"
                      placeholder="e.g. Astronaut animals, magic undersea dinosaurs"
                      value={state.theme}
                      onChange={(e) => setState(prev => ({ ...prev, theme: e.target.value, error: null }))}
                    />
                  </div>

                  {/* Generation Mode Select */}
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-3">
                      Drawing Art Style
                    </label>
                    <div className="grid grid-cols-2 gap-4">
                      {/* SVG Vector Drawing Option (Directly colorable!) */}
                      <button
                        type="button"
                        onClick={() => setState(prev => ({ ...prev, generationMode: "svg" }))}
                        className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden ${
                          state.generationMode === "svg"
                            ? "border-orange-400 bg-orange-50/50 ring-2 ring-orange-400/20"
                            : "border-slate-200 hover:border-slate-300 bg-white"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-sm">
                            Vector Sketch
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">Fast</span>
                          </h4>
                          {state.generationMode === "svg" && <div className="h-4 w-4 rounded-full bg-orange-500 flex items-center justify-center text-white text-[10px]">✓</div>}
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed">Crisp scalable drawings custom-embedded with names. Supports digital paint preview!</p>
                      </button>

                      {/* AI Masterpiece Image Option (Imagen) */}
                      <button
                        type="button"
                        onClick={() => setState(prev => ({ ...prev, generationMode: "imagen" }))}
                        className={`p-4 rounded-2xl border text-left transition-all ${
                          state.generationMode === "imagen"
                            ? "border-amber-400 bg-amber-50/50 ring-2 ring-amber-400/20"
                            : "border-slate-200 hover:border-slate-300 bg-white"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-sm">
                            AI Masterpiece
                            <span className="bg-amber-100 text-amber-800 text-[10px] px-1.5 py-0.5 rounded-full font-bold">HD</span>
                          </h4>
                          {state.generationMode === "imagen" && <div className="h-4 w-4 rounded-full bg-amber-500 flex items-center justify-center text-white text-[10px]">✓</div>}
                        </div>
                        <p className="text-xs text-slate-500 leading-relaxed">Highly detailed organic line-art generated using Imagen-4 model. (Automatic Vector fallback if quota runs out).</p>
                      </button>
                    </div>
                  </div>

                  {/* Primary submit action */}
                  <div className="pt-4">
                    <button
                      type="button"
                      disabled={state.isGeneratingOutline}
                      onClick={generateBookOutline}
                      className="w-full bg-slate-900 text-white font-display font-medium text-lg py-4 px-6 rounded-2xl shadow-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-2 disabled:bg-slate-300 disabled:cursor-not-allowed group"
                    >
                      {state.isGeneratingOutline ? (
                        <>
                          <RefreshCw className="h-5 w-5 animate-spin" />
                          <span>Generating Book Story Outline...</span>
                        </>
                      ) : (
                        <>
                          <span>Design Book Story Outlines</span>
                          <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Suggestions Sidepanel (The Instant Idea Starter) */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-[#FAF6F0] border border-orange-100/60 p-6 rounded-3xl">
                  <h3 className="font-display font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4 text-orange-400" />
                    Coloring Idea Starters
                  </h3>
                  <p className="text-xs text-slate-500 mb-5 leading-relaxed">
                    Tap a theme to instantly fill name and adventure settings to preview our crayon machine!
                  </p>

                  <div className="space-y-3">
                    {SUGGESTIONS.map((sug, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => handleApplySuggestion(sug)}
                        className="w-full p-3.5 bg-white rounded-2xl border border-slate-200/60 hover:border-orange-200 hover:shadow-md transition-all text-left flex items-center gap-4 group"
                      >
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${sug.color} flex items-center justify-center text-2xl shadow-sm text-center`}>
                          {sug.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-mono font-bold text-orange-600 uppercase tracking-widest leading-none mb-1">
                            {sug.name}'s Adventure
                          </p>
                          <p className="font-bold text-slate-800 text-sm truncate group-hover:text-slate-900">
                            {sug.theme}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-100/50 p-6 rounded-3xl border border-slate-200/50 flex gap-4 items-start">
                  <div className="p-2.5 rounded-2xl bg-white border border-slate-200 text-xl font-bold font-display shadow-sm">
                    🖨️
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm mb-1">100% Home Printable</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Custom outline structures. All designs are scaled for standard letter or A4 size printing with perfectly clean thick lines.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 2: BOOK DETAILS OUTLINE PREVIEW */}
          {state.currentStep === "outline" && state.bookOutline && (
            <motion.div
              key="outline-screen"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-8"
            >
              {/* Back Button */}
              <button
                onClick={() => setState(prev => ({ ...prev, currentStep: "setup" }))}
                className="flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800"
              >
                <ChevronLeft className="h-4 w-4" />
                <span>Back to settings</span>
              </button>

              <div className="bg-white border border-orange-100 p-8 rounded-3xl shadow-xl shadow-orange-500/5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-orange-50/70 mb-8">
                  <div>
                    <span className="text-xs font-mono font-bold text-orange-500 uppercase tracking-widest">PROPOSED VOLUME TITLE</span>
                    <h2 className="text-2xl font-bold font-display text-slate-900 mt-1">
                      {state.bookOutline.coverTitle}
                    </h2>
                  </div>
                  <div className="flex items-center gap-1 bg-amber-50 text-amber-800 px-3 py-1.5 rounded-full border border-amber-200/50 text-xs font-semibold shrink-0">
                    <BookOpen className="h-4 w-4" />
                    <span>5 Dynamic Coloring Chapters</span>
                  </div>
                </div>

                <p className="text-slate-600 text-sm mb-6 max-w-2xl leading-relaxed">
                  Gemini created a gorgeous 5-page story tailored for <strong>{state.childName}</strong>! Review the scene concepts below. You can refine the ideas yourself or click generate to start the drawings instantly.
                </p>

                {/* Grid list of proposed pages */}
                <div className="space-y-4">
                  {state.bookOutline.pages.map((p, index) => (
                    <div 
                      key={p.pageNumber || index}
                      className="p-5 border border-slate-200 hover:border-slate-300 rounded-2xl bg-slate-50/50 transition-all text-left grid grid-cols-1 md:grid-cols-12 gap-4 items-start"
                    >
                      {/* Number badge */}
                      <div className="md:col-span-1 flex md:flex-col items-center gap-2">
                        <span className="w-8 h-8 rounded-full bg-slate-900 text-white font-mono font-bold flex items-center justify-center text-sm shadow-sm">
                          {p.pageNumber}
                        </span>
                        <span className="text-xs text-slate-400 font-mono font-bold">PAGE</span>
                      </div>

                      {/* Details edit */}
                      <div className="md:col-span-11 space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-400 font-mono uppercase mb-1">PAGE TITLE</label>
                            <input 
                              type="text" 
                              className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl font-bold focus:outline-none focus:border-orange-400"
                              value={p.title}
                              onChange={(e) => handleUpdateOutlinePage(index, 'title', e.target.value)}
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-400 font-mono uppercase mb-1">STORY CAPTION (PRINTED ON PAGES)</label>
                            <input 
                              type="text" 
                              className="w-full px-3 py-2 text-sm bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-orange-400"
                              value={p.caption}
                              onChange={(e) => handleUpdateOutlinePage(index, 'caption', e.target.value)}
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label className="block text-[11px] font-bold text-slate-400 font-mono uppercase mb-1">ILLUSTRATION DRAWING PROMPT</label>
                          <textarea 
                            rows={2}
                            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-orange-400 font-mono text-slate-600 leading-relaxed"
                            value={p.prompt}
                            onChange={(e) => handleUpdateOutlinePage(index, 'prompt', e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Submitting trigger */}
                <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-end">
                  <button
                    type="button"
                    onClick={triggerGenerateAllPages}
                    className="bg-orange-500 text-white font-display text-lg py-4 px-10 rounded-2xl shadow-xl shadow-orange-500/10 hover:bg-orange-600 transition-all flex items-center gap-2 group font-semibold"
                  >
                    <span>Start drawing all coloring pages</span>
                    <Sparkles className="h-5 w-5 animate-pulse" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 3: ACTIVE PAGE GENERATION GRID */}
          {state.currentStep === "creating" && (
            <motion.div
              key="creating-screen"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-8"
            >
              <div className="bg-white border border-orange-100 p-8 rounded-3xl shadow-xl shadow-orange-500/5 text-center max-w-3xl mx-auto">
                <div className="inline-flex relative mb-4">
                  <span className="text-5xl animate-bounce">🖍️</span>
                  <motion.span 
                    className="absolute -top-1 -right-3 text-3xl"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 1.5 }}
                  >
                    ✨
                  </motion.span>
                </div>
                
                <h2 className="text-2xl font-bold font-display text-slate-900">
                  Drawn on paper... Wait page drafts!
                </h2>
                <p className="text-slate-500 text-sm max-w-md mx-auto mt-2 leading-relaxed">
                  We are custom-drawing 5 black-and-white vector line sheets centered on "{state.theme}". This will take around 25-40 seconds.
                </p>

                {/* Status Bento Boxes */}
                <div className="mt-8 grid grid-cols-1 sm:grid-cols-5 gap-4">
                  {state.generatedPages.map((page, i) => (
                    <div 
                      key={page.pageNumber || i}
                      className={`p-4 rounded-2xl border transition-all flex flex-col justify-between h-36 ${
                        page.status === "success" 
                          ? "border-emerald-200 bg-emerald-50/40" 
                          : page.status === "error"
                          ? "border-red-200 bg-red-50/40"
                          : page.status === "generating"
                          ? "border-orange-200 bg-orange-50/50"
                          : "border-slate-200 bg-white"
                      }`}
                    >
                      <div>
                        <span className="text-[10px] font-mono font-bold text-slate-400">PAGE {page.pageNumber}</span>
                        <h4 className="font-bold text-slate-800 text-xs line-clamp-2 mt-1">{page.title}</h4>
                      </div>

                      <div className="flex items-center justify-center pt-3">
                        {page.status === "pending" && (
                          <div className="w-6 h-6 rounded-full border-2 border-slate-200 flex items-center justify-center">
                            <div className="w-2 h-2 rounded-full bg-slate-300" />
                          </div>
                        )}
                        {page.status === "generating" && (
                          <div className="w-8 h-8 rounded-full border-2 border-t-orange-500 border-orange-100 animate-spin" />
                        )}
                        {page.status === "success" && (
                          <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center text-sm shadow-md shadow-emerald-500/10">
                            ✓
                          </div>
                        )}
                        {page.status === "error" && (
                          <div className="w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center text-sm shadow-md shadow-red-500/10" title={page.error}>
                            !
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Live progress details */}
                <div className="mt-8 flex items-center justify-center gap-3 text-xs font-mono text-slate-400">
                  <div className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                  <span>ENGAGE COLORING MATRICES • ACTIVE SYSTEM RENDER</span>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 4: DOWNLOAD & PRINT HUB */}
          {state.currentStep === "finished" && (
            <motion.div
              key="finished-screen"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              {/* Left Canvas: Coloring Book Page Viewer & Digital Coloring */}
              <div className="lg:col-span-7 bg-white rounded-3xl border border-orange-100 shadow-xl shadow-orange-500/5 p-6 space-y-6">
                
                {/* Book Navigation bar */}
                <div className="flex items-center justify-between border-b border-orange-50/50 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center font-bold text-sm">
                      {activePage?.pageNumber}/{state.generatedPages.length}
                    </span>
                    <div>
                      <h3 className="font-bold font-display text-slate-800 leading-tight">
                        {activePage?.title}
                      </h3>
                      <p className="text-xs font-mono text-slate-400 tracking-wide uppercase">
                        {activePage?.type === "svg" ? "Vector Line Art (Custom SVG)" : "AI Masterpiece Image"} {activePage?.isFallback && "(Vector Fallback)"}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setActivePageIndex(prev => Math.max(0, prev - 1))}
                      disabled={activePageIndex === 0}
                      className="p-2.5 rounded-full border border-slate-200/60 hover:bg-slate-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <ChevronLeft className="h-4 w-4 text-slate-600" />
                    </button>
                    <button
                      onClick={() => setActivePageIndex(prev => Math.min(state.generatedPages.length - 1, prev + 1))}
                      disabled={activePageIndex === state.generatedPages.length - 1}
                      className="p-2.5 rounded-full border border-slate-200/60 hover:bg-slate-50 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <ChevronRight className="h-4 w-4 text-slate-600" />
                    </button>
                  </div>
                </div>

                {/* Interactive Paint Box Palette for direct coloring */}
                {activePage?.type === "svg" && (
                  <div className="p-4 bg-orange-50/40 rounded-2xl border border-orange-100/60 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-mono text-orange-600 tracking-wide uppercase flex items-center gap-1">
                        <Paintbrush className="h-3 w-3" />
                        Interactive Color Crayon Tester
                      </span>
                      <button 
                        onClick={() => clearDigitalColors(activePage.pageNumber)}
                        className="text-[10px] text-slate-400 hover:text-red-500 font-mono underline"
                      >
                        Reset Paints
                      </button>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {PASTEL_PALETTE.map((color) => (
                        <button
                          key={color.value}
                          onClick={() => setSelectedPaintColor(color.value)}
                          className="w-8 h-8 rounded-full border-2 transition-all relative shrink-0"
                          style={{ 
                            backgroundColor: color.value, 
                            borderColor: selectedPaintColor === color.value ? "#000" : "transparent"
                          }}
                          title={color.name}
                        >
                          {selectedPaintColor === color.value && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <Check className="h-3.5 w-3.5 text-slate-900 stroke-[3]" />
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-400 leading-relaxed md:w-3/4">
                      💡 Click on any shape inside the digital canvas drawing below to paint it! This colored view will be preserved in the generated PDF cover book!
                    </p>
                  </div>
                )}

                {/* Painting Area Frame (Print target) */}
                <div className="border border-slate-200 rounded-2xl bg-white overflow-hidden shadow-inner relative flex justify-center p-3 relative select-none">
                  <div className="w-full max-w-lg aspect-[4/5] bg-white border border-slate-100 relative flex items-center justify-center">
                    
                    {activePage?.status === "generating" ? (
                      <div className="space-y-3 text-center">
                        <div className="w-10 h-10 border-4 border-slate-200 border-t-orange-500 rounded-full animate-spin mx-auto" />
                        <span className="text-sm text-slate-500 font-medium">Re-drawing canvas lines...</span>
                      </div>
                    ) : activePage?.type === "svg" ? (
                      /* RENDER INTERACTIVE INTERCEPTED CLICKABLE SVG INLINE */
                      <div 
                        onClick={(e) => handleSvgClick(e, activePage.pageNumber)}
                        className="w-full h-full relative cursor-crosshair align-middle flex items-center justify-center [&>svg]:max-w-full [&>svg]:max-h-full [&>svg]:w-full [&>svg]:h-full [&_path]:transition-colors [&_path]:duration-300 [&_circle]:transition-colors [&_circle]:duration-300 [&_rect]:transition-colors [&_rect]:duration-300 pointer-events-auto"
                        dangerouslySetInnerHTML={{ 
                          // Highlight or override fill for elements using standard client-rendered style overrides
                          __html: activePage.content
                        }}
                        ref={pagePrintRef}
                      />
                    ) : (
                      /* RENDER TRADITIONAL HIGH RES JPG FORMAT */
                      <img 
                        src={activePage?.content} 
                        alt={activePage?.title} 
                        className="w-full h-full object-contain pointer-events-none"
                        referrerPolicy="no-referrer"
                      />
                    )}

                    {/* Captions Frame overlay simulation */}
                    <div className="absolute bottom-5 left-5 right-5 bg-slate-50 border border-slate-200/80 rounded-xl py-2 px-3 text-center">
                      <p className="text-xs font-bold text-slate-700">{activePage?.caption}</p>
                    </div>

                    {/* Applied Color Injector Layer (Applies dynamic coloring on render dynamically using standard client style blocks) */}
                    {activePage?.type === "svg" && interactiveColors[activePage.pageNumber] && (
                      <style dangerouslySetInnerHTML={{
                        __html: Object.entries(interactiveColors[activePage.pageNumber])
                          .map(([elId, color]) => `[id="${elId}"], #${elId} { fill: ${color} !important; }`)
                          .join("\n")
                      }} />
                    )}

                  </div>
                </div>
              </div>

              {/* Right Side: PDF Compilation Controls and Print Station */}
              <div className="lg:col-span-5 space-y-6">
                
                {/* PDF Compilation Terminal */}
                <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-xl border border-slate-800 space-y-6 relative overflow-hidden">
                  <div className="absolute -bottom-10 -left-10 w-44 h-44 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
                  
                  <div className="flex items-center gap-2">
                    <span className="text-3xl">📘</span>
                    <div>
                      <h3 className="font-bold font-display text-lg text-amber-300">Assemble Printable Book</h3>
                      <p className="text-slate-400 text-xs">READY FOR CRATER PRINTING</p>
                    </div>
                  </div>

                  <div className="space-y-4 pt-2">
                    <div className="bg-slate-800/65 rounded-2xl p-4 border border-slate-800 text-xs text-slate-300 leading-relaxed space-y-1.5">
                      <p className="font-bold text-slate-200">The collection includes:</p>
                      <ul className="list-disc pl-5 space-y-1 text-slate-400">
                        <li>Cover Page with child's name: <strong>{state.childName}</strong></li>
                        <li>5 Story Chapters on: <strong>{state.theme}</strong></li>
                        <li>Centered bottom chapter narrative subtitles</li>
                        <li>Your custom crayon paint styling presets!</li>
                      </ul>
                    </div>

                    {/* PDF Compile action button */}
                    <button
                      type="button"
                      disabled={isPdfDownloading}
                      onClick={handleDownloadPdf}
                      className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-display font-medium text-base py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2 shadow-amber-400/10 disabled:bg-slate-700 disabled:cursor-not-allowed group font-bold"
                    >
                      {isPdfDownloading ? (
                        <>
                          <RefreshCw className="h-5 w-5 animate-spin text-slate-950" />
                          <span className="text-sm font-semibold text-slate-950">{pdfGenerationMsg || "Compiling..."}</span>
                        </>
                      ) : (
                        <>
                          <Download className="h-5 w-5" />
                          <span>Download pdf coloring book</span>
                        </>
                      )}
                    </button>
                    
                    {/* Native print trigger */}
                    <button
                      type="button"
                      onClick={handlePrint}
                      className="w-full bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white font-medium text-xs py-3 rounded-2xl transition-all flex items-center justify-center gap-1.5"
                    >
                      <Printer className="h-4 w-4" />
                      <span>Direct Browser Print</span>
                    </button>
                  </div>
                </div>

                {/* Book Outline Quick list navigation */}
                <div className="bg-[#FAF6F0] rounded-3xl p-6 border border-orange-100/60 max-h-[350px] overflow-y-auto space-y-3">
                  <h4 className="font-bold font-display text-slate-700 text-sm mb-1 flex items-center gap-1">
                    <BookOpen className="h-4 w-4 text-orange-400" />
                    Coloring Pages index
                  </h4>

                  <div className="space-y-2">
                    {state.generatedPages.map((page, i) => (
                      <button
                        key={page.pageNumber || i}
                        onClick={() => setActivePageIndex(i)}
                        className={`w-full p-3 rounded-xl border text-left flex items-center gap-3 transition-all ${
                          activePageIndex === i 
                            ? "bg-white border-orange-300 shadow-sm font-semibold" 
                            : "bg-transparent border-transparent hover:bg-white/40"
                        }`}
                      >
                        <span className={`w-6 h-6 rounded-lg font-mono font-bold text-xs flex items-center justify-center shrink-0 ${
                          activePageIndex === i ? "bg-slate-900 text-white" : "bg-slate-200/70 text-slate-500"
                        }`}>
                          {page.pageNumber}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className={`text-xs truncate ${activePageIndex === i ? "text-slate-900 font-bold" : "text-slate-600 font-medium"}`}>
                            {page.title}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Back button to start from scratch */}
                <button
                  onClick={resetApp}
                  className="w-full py-4 text-center text-sm font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 rounded-2xl border border-slate-200/50 transition-all"
                >
                  Create Another Coloring Book 📚🚀
                </button>
              </div>

            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="max-w-6xl mx-auto border-t border-orange-100/50 py-10 px-6 mt-12 text-center text-xs text-slate-400 w-full font-mono">
        <p>© 2026 COLORING BOOK GENERATOR • DESIGN ENVIRONMENT PORT 3000</p>
        <p className="mt-1">CUSTOM-BUILT FOR ADVENTURES • FOR THE LOVE OF CREATIVE COATING</p>
      </footer>
    </div>
  );
}
